$(document).ready(function () {
  $('[data-target=".menulabel"]').click(function () {
    $('.row-sidebar-collapse').toggleClass('closed')
  });
});